// Listen for messages from content script
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === 'openVideoPlayer') {
    // Create a popup window with the video player
    chrome.windows.create({
      url: 'popup.html',
      type: 'popup',
      width: 640,
      height: 360,
      focused: true
    });
  }
}); 